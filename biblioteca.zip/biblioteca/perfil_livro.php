<?php
include "config.php";
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$id_livro = $_GET['id'];

// Consultar informações do livro
$query_livro = "SELECT * FROM livros WHERE id_livro = '$id_livro'";
$result_livro = mysqli_query($conn, $query_livro);
$livro = mysqli_fetch_assoc($result_livro);

// Verificar se o livro está emprestado
$livro_emprestado = false;
$id_aluno = null;
$nome_aluno = null;
$data_emprestimo = null;

if ($livro['situacao'] == 'emprestado') {
    $livro_emprestado = true;

    // Consultar informações do empréstimo
    $query_emprestimo = "SELECT * FROM emprestimos WHERE id_livro = '$id_livro' AND data_devolucao IS NULL LIMIT 1";
    $result_emprestimo = mysqli_query($conn, $query_emprestimo);
    
    if (mysqli_num_rows($result_emprestimo) > 0) {
        $emprestimo = mysqli_fetch_assoc($result_emprestimo);
        $id_aluno = $emprestimo['id_aluno'];
        $data_emprestimo = $emprestimo['data_emprestimo'];

        // Consultar nome do aluno
        $query_aluno = "SELECT nome FROM alunos WHERE id_aluno = '$id_aluno'";
        $result_aluno = mysqli_query($conn, $query_aluno);
        $aluno = mysqli_fetch_assoc($result_aluno);
        $nome_aluno = $aluno['nome'];
    }
}

// Lidar com a devolução
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['devolver'])) {
    $query_devolucao = "UPDATE emprestimos SET data_devolucao = NOW() WHERE id_livro = '$id_livro' AND data_devolucao IS NULL";
    mysqli_query($conn, $query_devolucao);

    // Atualizar a situação do livro
    $query_update = "UPDATE livros SET situacao = 'Disponível' WHERE id_livro = '$id_livro'";
    mysqli_query($conn, $query_update);

    echo "<script>alert('Devolução registrada com sucesso!'); window.location.href='perfil_livro.php?id=$id_livro';</script>";
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Detalhes do Livro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2><?php echo $livro['titulo']; ?></h2>
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo $livro['imagem_url']; ?>" class="img-fluid" alt="<?php echo $livro['titulo']; ?>">
            </div>
            <div class="col-md-6">
                <p>Autor: <?php echo $livro['autor']; ?></p>
                <p>Status: <?php echo $livro['situacao']; ?></p>

                <?php if ($livro_emprestado) : ?>
                    <p>Emprestado para: <a href="perfil_aluno.php?id=<?php echo $id_aluno; ?>"><?php echo $nome_aluno; ?></a></p>
                    <form method="POST" action="">
                        <button type="submit" name="devolver" class="btn btn-danger">Comunicar Devolução</button>
                    </form>
                <?php else : ?>
                    <a href="emprest_livro.php?id=<?php echo $livro['id_livro']; ?>" class="btn btn-success">Comunicar Empréstimo</a>
                <?php endif; ?>

                
                
            </div>
        </div>
    </div>

    <?php mysqli_close($conn); ?>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

