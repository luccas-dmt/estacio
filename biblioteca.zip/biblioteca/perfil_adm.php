<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
    <script>
        function confirmDelete() {
            return confirm('Tem certeza que deseja excluir este administrador?');
        }
    </script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php
    include "config.php";
    session_start();

    // Verifique se o ID foi passado na URL
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "ID do administrador não fornecido.";
        exit;
    }

    // Captura o ID e converte para inteiro
    $id_admin = intval($_GET['id']);

    if (!isset($_SESSION['loggedin'])) {
        header('Location: login.php');
        exit;
    }

    // Consulta o banco de dados para obter as informações do administrador
    $query = "SELECT * FROM admins WHERE id_admin = $id_admin";
    $result = mysqli_query($conn, $query);

    // Verifica se a consulta retornou um resultado
    if (!$result) {
        echo "Erro na consulta: " . mysqli_error($conn);
        exit;
    }

    if (mysqli_num_rows($result) > 0) {
        $adm = mysqli_fetch_assoc($result);
    } else {
        echo "Administrador não encontrado.";
        exit;
    }
    ?>

    <div class="container mt-4">
        <h2 class="text-center">Perfil do Administrador</h2>
        <p>Nome: <?php echo htmlspecialchars($adm['nome']); ?></p>
        <p>CPF: <?php echo htmlspecialchars($adm['cpf']); ?></p>

        <a href="edit_adm.php?id=<?php echo $adm['id_admin']; ?>" class="btn btn-primary">Editar</a>
        <form method="POST" action="perfil_adm.php?id=<?php echo $adm['id_admin']; ?>" onsubmit="return confirmDelete();" style="display:inline;">
            <button type="submit" name="delete" class="btn btn-danger">Excluir</button>
        </form>
        <a href="lista_alu.php" class="btn btn-secondary">Voltar</a>
    </div>

    <?php
    // Lógica de exclusão
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
        // Excluir o administrador
        $query_delete = "DELETE FROM admins WHERE id_admin='$id_admin'";
        
        if (mysqli_query($conn, $query_delete)) {
            echo "<script>alert('Administrador excluído com sucesso!'); window.location.href='lista_adm.php';</script>";
        } else {
            echo "<script>alert('Erro ao excluir administrador: " . mysqli_error($conn) . "');</script>";
        }
    }

    mysqli_close($conn);
    ?>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





