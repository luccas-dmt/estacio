-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.25-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para biblioteca
DROP DATABASE IF EXISTS `biblioteca`;
CREATE DATABASE IF NOT EXISTS `biblioteca` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `biblioteca`;

-- Copiando estrutura para tabela biblioteca.admins
DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` char(11) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`id_admin`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela biblioteca.admins: ~1 rows (aproximadamente)
REPLACE INTO `admins` (`id_admin`, `nome`, `cpf`, `senha`) VALUES
	(4, 'admin', '123', '$2y$10$T8zB12c7ImR7D.2RG9ZxOe7JfyH/Dh7Pd8xzMF/fgniXStfdoCba2');

-- Copiando estrutura para tabela biblioteca.alunos
DROP TABLE IF EXISTS `alunos`;
CREATE TABLE IF NOT EXISTS `alunos` (
  `id_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `numero_matricula` varchar(20) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `curso` varchar(100) NOT NULL,
  `cpf` varchar(50) NOT NULL DEFAULT '',
  `data_atualizacao` date NOT NULL,
  PRIMARY KEY (`id_aluno`),
  UNIQUE KEY `numero_matricula` (`numero_matricula`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela biblioteca.alunos: ~1 rows (aproximadamente)
REPLACE INTO `alunos` (`id_aluno`, `numero_matricula`, `nome`, `curso`, `cpf`, `data_atualizacao`) VALUES
	(1, '12345', 'luccas dmt', 'informatica', '12345', '0000-00-00');

-- Copiando estrutura para tabela biblioteca.emprestimos
DROP TABLE IF EXISTS `emprestimos`;
CREATE TABLE IF NOT EXISTS `emprestimos` (
  `id_emprestimo` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) DEFAULT NULL,
  `id_livro` int(11) DEFAULT NULL,
  `data_emprestimo` date NOT NULL,
  `data_devolucao` date DEFAULT NULL,
  PRIMARY KEY (`id_emprestimo`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_livro` (`id_livro`),
  CONSTRAINT `emprestimos_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id_aluno`),
  CONSTRAINT `emprestimos_ibfk_2` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id_livro`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela biblioteca.emprestimos: ~2 rows (aproximadamente)
REPLACE INTO `emprestimos` (`id_emprestimo`, `id_aluno`, `id_livro`, `data_emprestimo`, `data_devolucao`) VALUES
	(1, 1, 2, '2024-09-30', '2024-09-30'),
	(2, 1, 2, '2024-09-30', '2024-09-30');

-- Copiando estrutura para tabela biblioteca.livros
DROP TABLE IF EXISTS `livros`;
CREATE TABLE IF NOT EXISTS `livros` (
  `id_livro` int(11) NOT NULL AUTO_INCREMENT,
  `numero_patrimonio` varchar(20) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `imagem_url` varchar(255) DEFAULT NULL,
  `situacao` enum('disponível','emprestado') NOT NULL DEFAULT 'disponível',
  PRIMARY KEY (`id_livro`),
  UNIQUE KEY `numero_patrimonio` (`numero_patrimonio`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela biblioteca.livros: ~5 rows (aproximadamente)
REPLACE INTO `livros` (`id_livro`, `numero_patrimonio`, `titulo`, `autor`, `imagem_url`, `situacao`) VALUES
	(1, '00001', 'Introdução à Programação com Python: Algoritmos e Lógica de Programação Para Iniciantes', ' Nilo Ney Coutinho Menezes', 'imgs\\catalogo\\python.jpeg', 'disponível'),
	(2, '00002', 'JavaScript: O Guia Definitivo', ' David Flanagan ', 'imgs\\catalogo\\js.jpg', 'disponível'),
	(3, '00003', 'Fundamentos de HTML5 e CSS3', ' Maurício Samy Silva ', 'imgs\\catalogo\\htmlcss.jpg', 'disponível'),
	(4, '00004', 'Redes de Computadores', ' Andrew Tanenbaum, Nick Feamster', 'imgs\\catalogo\\redes.jpg', 'disponível'),
	(5, '00005', 'Sistemas de Banco de Dados', 'Ramez Elmasri, Shamkant B. Navathe', 'imgs\\catalogo\\sbd.jpg', 'disponível');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
