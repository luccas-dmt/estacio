<?php
include "config.php";
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $numero_patrimonio = $_POST['numero_patrimonio'];
    $imagem_url = '';

    // Upload da imagem
    if ($_FILES['imagem']['error'] == 0) {
        $nome_arquivo = basename($_FILES['imagem']['name']);
        $caminho_arquivo = 'imgs/catalogo/' . $nome_arquivo;
        move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho_arquivo);
        $imagem_url = $caminho_arquivo;
    }

    // Inserir no banco de dados
    $query = "INSERT INTO livros (titulo, autor, numero_patrimonio, imagem_url, situacao) VALUES ('$titulo', '$autor', '$numero_patrimonio', '$imagem_url', 'Disponível')";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    echo "Livro adicionado com sucesso!";
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Adicionar Livro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
        .form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .form-container label {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="form-container">
        <h2 class="text-center">Adicionar Livro</h2>
        <form action="add_livro.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="titulo">Título:</label>
                <input type="text" class="form-control" id="titulo" name="titulo" required>
            </div>
            <div class="mb-3">
                <label for="autor">Autor:</label>
                <input type="text" class="form-control" id="autor" name="autor">
            </div>
            <div class="mb-3">
                <label for="numero_patrimonio">Número de Patrimônio:</label>
                <input type="text" class="form-control" id="numero_patrimonio" name="numero_patrimonio" required>
            </div>
            <div class="mb-3">
                <label for="imagem">Imagem do Livro:</label>
                <input type="file" class="form-control" id="imagem" name="imagem">
            </div>
            <button type="submit" class="btn btn-success">Salvar Livro</button>
        </form>
    </div>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>






