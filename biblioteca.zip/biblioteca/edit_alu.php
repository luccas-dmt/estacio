<?php
include "config.php";
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$id_aluno = $_GET['id'];

// Consultar informações do aluno
$query_aluno = "SELECT * FROM alunos WHERE id_aluno = '$id_aluno'";
$result_aluno = mysqli_query($conn, $query_aluno);
$aluno = mysqli_fetch_assoc($result_aluno);

// Lidar com o formulário de edição
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $matricula = $_POST['matricula'];
    $curso = $_POST['curso'];

    $query_update = "UPDATE alunos SET nome='$nome', cpf='$cpf', numero_matricula='$matricula', curso='$curso' WHERE id_aluno='$id_aluno'";
    mysqli_query($conn, $query_update);

    echo "<script>alert('Aluno atualizado com sucesso!'); window.location.href='lista_alu.php';</script>";
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Aluno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
        <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="catalog.php">Catálogo</a></li>
                    <li class="nav-item"><a class="nav-link" href="lista_alu.php">Alunos</a></li>
                    <li class="nav-item"><a class="nav-link" href="emprestimos.php">Empréstimos</a></li>
                    <li class="nav-item"><a class="nav-link" href="lista_adm.php">Admin</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Sair</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Editar Aluno</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $aluno['nome']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF</label>
                <input type="text" class="form-control" id="cpf" name="cpf" value="<?php echo $aluno['cpf']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="matricula" class="form-label">Matrícula</label>
                <input type="text" class="form-control" id="matricula" name="matricula" value="<?php echo $aluno['numero_matricula']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="curso" class="form-label">Curso</label>
                <input type="text" class="form-control" id="curso" name="curso" value="<?php echo $aluno['curso']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Atualizar</button>
            <a href="lista_alu.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

    <?php mysqli_close($conn); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
