<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Aluno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php
    include "config.php";
    session_start();
    if (!isset($_SESSION['loggedin'])) {
        header('Location: login.php');
        exit;
    }

    $id_aluno = $_GET['id'];

    $query = "SELECT * FROM alunos WHERE id_aluno = $id_aluno";
    $result = mysqli_query($conn, $query);
    $aluno = mysqli_fetch_assoc($result);

    // Verifica se o aluno foi encontrado
    if (!$aluno) {
        echo "<script>alert('Aluno não encontrado!'); window.location.href='lista_alu.php';</script>";
        exit;
    }

 
    ?>

    <div class="container mt-4">
        <h2 class="text-center">Perfil do Aluno</h2>
        <p><strong>Nome:</strong> <?php echo htmlspecialchars($aluno['nome']); ?></p>
        <p><strong>CPF:</strong> <?php echo htmlspecialchars($aluno['cpf']); ?></p>
        <p><strong>Matrícula:</strong> <?php echo htmlspecialchars($aluno['numero_matricula']); ?></p>
        <p><strong>Curso:</strong> <?php echo htmlspecialchars($aluno['curso']); ?></p>

        <a href="edit_alu.php?id=<?php echo $aluno['id_aluno']; ?>" class="btn btn-primary">Editar</a>
        <a href="lista_alu.php" class="btn btn-secondary">Voltar</a>
    </div>

    <?php mysqli_close($conn); ?>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



