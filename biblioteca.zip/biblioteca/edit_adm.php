<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Editar Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php
    include "config.php";
    session_start();

    // Verifique se o ID foi passado na URL
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "ID do administrador não fornecido.";
        exit;
    }

    // Captura o ID e converte para inteiro
    $id_admin = intval($_GET['id']);

    if (!isset($_SESSION['loggedin'])) {
        header('Location: login.php');
        exit;
    }

    // Consulta o banco de dados para obter as informações do administrador
    $query = "SELECT * FROM admins WHERE id_admin = $id_admin";
    $result = mysqli_query($conn, $query);

    // Verifica se a consulta retornou um resultado
    if (!$result) {
        echo "Erro na consulta: " . mysqli_error($conn);
        exit;
    }

    if (mysqli_num_rows($result) > 0) {
        $adm = mysqli_fetch_assoc($result);
    } else {
        echo "Administrador não encontrado.";
        exit;
    }

    // Lógica para atualizar as informações do administrador
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $senha = $_POST['senha'];

        // Se a senha for preenchida, atualiza a senha
        if (!empty($senha)) {
            $senha = password_hash($senha, PASSWORD_DEFAULT);
            $query_update = "UPDATE admins SET nome='$nome', cpf='$cpf', senha='$senha' WHERE id_admin='$id_admin'";
        } else {
            $query_update = "UPDATE admins SET nome='$nome', cpf='$cpf' WHERE id_admin='$id_admin'";
        }

        if (mysqli_query($conn, $query_update)) {
            echo "<script>alert('Administrador atualizado com sucesso!'); window.location.href='lista_adm.php';</script>";
        } else {
            echo "<script>alert('Erro ao atualizar administrador: " . mysqli_error($conn) . "');</script>";
        }
    }
    ?>

    <div class="container mt-4">
        <h2 class="text-center">Editar Administrador</h2>
        <form method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($adm['nome']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF</label>
                <input type="text" class="form-control" id="cpf" name="cpf" value="<?php echo htmlspecialchars($adm['cpf']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Nova Senha (deixe em branco para não alterar)</label>
                <input type="password" class="form-control" id="senha" name="senha">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>

    <?php mysqli_close($conn); ?>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
