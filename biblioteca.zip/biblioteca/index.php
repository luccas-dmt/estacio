<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biblioteca virtual</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
        .book-image {
            width: 100%; /* Para ocupar toda a largura do col */
            height: 400px; /* Ajuste a altura conforme necessário */
            object-fit: cover; /* Mantém a proporção da imagem */
        }
        h5 {
            font-size: 1rem; /* Diminui o tamanho da fonte dos títulos dos livros */
        }
        .mt-4 { 
            margin-top: 4rem; /* Espaço maior entre o nav bar e o h2 */
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Bootstrap" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto"> 
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="login.php">Entrar</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <h2 class="text-center mb-4">Catálogo</h2>
        <div class="row">
            <?php
            include "config.php";

            
            $query = "SELECT * FROM livros"; 
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($livro = mysqli_fetch_assoc($result)) {
                    echo '<div class="col-md-3 mb-4">'; 
                    echo '<img src="' . $livro['imagem_url'] . '" alt="' . $livro['titulo'] . '" class="book-image img-fluid">'; // Imagem do livro
                    echo '<h5>' . $livro['titulo'] . '</h5>'; 
                    echo '<p>Status: ' . $livro['situacao'] . '</p>'; 
                    echo '</div>'; 
                }
            } else {
                echo '<div class="col-12">Nenhum livro encontrado.</div>';
            }

   
            mysqli_close($conn);
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>






