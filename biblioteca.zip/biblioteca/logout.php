<?php
include "config.php";
session_start(); 


if (isset($_SESSION['loggedin'])) {

    $_SESSION = array(); 


    session_destroy();


    header('Location: index.php');
    exit;
} else {

    header('Location: index.php');
    exit;
}
?>

