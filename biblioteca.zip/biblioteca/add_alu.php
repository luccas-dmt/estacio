<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    include "config.php";
    session_start();
    if (!isset($_SESSION['loggedin'])) {
        header('Location: login.php');
        exit;
    }

    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $matricula = $_POST['matricula'];
    $curso = $_POST['curso'];

    

    $query = "INSERT INTO alunos (nome, cpf, numero_matricula, curso) VALUES ('$nome', '$cpf', '$matricula', '$curso')";
    mysqli_query($conn, $query);
    mysqli_close($conn);
    echo "Aluno adicionado com sucesso!";
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Biblioteca - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-custom {
            background-color: #001BA9 !important;
        }
        .nav-link {
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="imgs/nav.png" alt="Logo" width="150" height="28">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="catalog.php">Catálogo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_alu.php">Alunos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="emprestimos.php">Empréstimos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_adm.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
    <div class="bg-light p-4 rounded mx-auto" style="max-width: 500px;">
        <form action="add_alu.php" method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" name="nome" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="cpf" class="form-label">CPF:</label>
                <input type="text" name="cpf" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="matricula" class="form-label">Matrícula:</label>
                <input type="text" name="matricula" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="curso" class="form-label">Curso:</label>
                <input type="text" name="curso" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-success">Salvar Aluno</button>
        </form>
    </div>
</div>

    <!-- Scripts Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>






